public class IncrementDecrement {
    public static void main(String[] args) {
        int a = 5;
        int b = 10;

        int result = ++a + b--;

        System.out.println("Result: " + result);
        
    }
}
